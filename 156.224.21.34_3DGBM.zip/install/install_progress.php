<?php
session_start();

class InstallProgress {
    private static $initialized = false;
    
    public static function initialize() {
        if (!self::$initialized) {
            if (!isset($_SESSION['install'])) {
                $_SESSION['install'] = [
                    'current_step' => 1,
                    'completed' => []
                ];
            }
            self::$initialized = true;
        }
    }

    public static function validateStep($requestedStep) {
        self::initialize();
        
        $current = $_SESSION['install']['current_step'];
        $completed = $_SESSION['install']['completed'];

        // 允许访问已完成步骤
        if (in_array($requestedStep, $completed)) return;

        // 阻止访问未来步骤
        if ($requestedStep > $current) {
            header("Location: step{$current}.php");
            exit;
        }
    }

    public static function completeStep($step) {
        self::initialize();
        
        if (!in_array($step, $_SESSION['install']['completed'])) {
            $_SESSION['install']['completed'][] = $step;
            $_SESSION['install']['current_step'] = max(
                $_SESSION['install']['current_step'], 
                $step + 1
            );
        }
    }
}