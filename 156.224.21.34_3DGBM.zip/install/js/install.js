// 第一步：环境检测
document.addEventListener('DOMContentLoaded', function() {
    // 检测PHP版本
    const phpVersionCheck = document.getElementById('phpVersionCheck');
    const phpVersion = parseFloat(navigator.userAgent.match(/PHP\/([\d.]+)/)?.[1] || 0);
    if (phpVersion >= 8.2) {
        phpVersionCheck.classList.add('success');
        phpVersionCheck.querySelector('.check-message').textContent = 'PHP版本 ' + phpVersion + ' ✓';
    } else {
        phpVersionCheck.classList.add('error');
        phpVersionCheck.querySelector('.check-message').textContent = 'PHP版本 ' + phpVersion + ' ✗ (需要 8.2+)';
    }

    // 检测MySQLi扩展
    const mysqliCheck = document.getElementById('mysqliCheck');
    if (typeof mysqli !== 'undefined') {
        mysqliCheck.classList.add('success');
        mysqliCheck.querySelector('.check-message').textContent = 'MySQLi扩展 ✓';
    } else {
        mysqliCheck.classList.add('error');
        mysqliCheck.querySelector('.check-message').textContent = 'MySQLi扩展 ✗';
    }

    // 检测PDO扩展
    const pdoCheck = document.getElementById('pdoCheck');
    if (typeof PDO !== 'undefined') {
        pdoCheck.classList.add('success');
        pdoCheck.querySelector('.check-message').textContent = 'PDO扩展 ✓';
    } else {
        pdoCheck.classList.add('error');
        pdoCheck.querySelector('.check-message').textContent = 'PDO扩展 ✗';
    }

    // 检测mbstring扩展
    const mbstringCheck = document.getElementById('mbstringCheck');
    if (typeof mbstring !== 'undefined') {
        mbstringCheck.classList.add('success');
        mbstringCheck.querySelector('.check-message').textContent = 'mbstring扩展 ✓';
    } else {
        mbstringCheck.classList.add('error');
        mbstringCheck.querySelector('.check-message').textContent = 'mbstring扩展 ✗';
    }

    // 检查是否所有检测通过
    const checkItems = document.querySelectorAll('.check-item');
    let allPassed = true;
    checkItems.forEach(item => {
        if (!item.classList.contains('success')) {
            allPassed = false;
        }
    });

    if (allPassed) {
        document.getElementById('nextStepBtn').classList.remove('hidden');
        document.getElementById('nextStepBtn').disabled = false;
    }
});

// 第二步：数据库配置
document.getElementById('dbConfigForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const formData = new FormData(this);

    // 验证表单字段
    const dbHost = formData.get('dbHost');
    const dbPort = formData.get('dbPort');
    const dbName = formData.get('dbName');
    const dbUser = formData.get('dbUser');
    const dbPassword = formData.get('dbPassword');
    const adminUsername = formData.get('adminUsername');
    const adminPassword = formData.get('adminPassword');
    const adminEmail = formData.get('adminEmail');

    if (!dbHost || !dbPort || !dbName || !dbUser || !adminPassword || !adminUsername || !adminEmail) {
        alert('请填写所有必填字段');
        return;
    }

    try {
        // 发送表单数据到 save_config.php
        const response = await fetch('save_config.php', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        console.log('save_config.php 响应:', data);

        if (data.success) {
            // 保存配置成功，更新安装进度并跳转到第三步
            const progressResponse = await fetch('update_progress.php?step=2');

            if (!progressResponse.ok) {
                throw new Error(`HTTP error! status: ${progressResponse.status}`);
            }

            const progressData = await progressResponse.json();
            console.log('update_progress.php 响应:', progressData);

            if (progressData.success) {
                window.location.href = 'step3.php';
            } else {
                alert('更新安装进度失败: ' + progressData.error);
            }
        } else {
            alert('保存配置失败: ' + data.message);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('保存配置时出现错误: ' + error.message);
    }
});

// 第三步：安装数据库
document.addEventListener('DOMContentLoaded', function() {
    // 模拟安装进度
    let progress = document.getElementById('progress');
    let statusText = document.getElementById('statusText');
    let width = 0;

    const interval = setInterval(function() {
        if (width >= 100) {
            clearInterval(interval);
            completeInstallation();
        } else {
            width += 5;
            progress.style.width = width + '%';

            if (width < 30) {
                statusText.textContent = '正在连接数据库...';
            } else if (width < 60) {
                statusText.textContent = '正在创建表结构...';
            } else {
                statusText.textContent = '正在插入初始数据...';
            }
        }
    }, 200);
});

function completeInstallation() {
    // 创建install.lock文件
    fetch('step3.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            dbHost: 'localhost',
            dbPort: '3306',
            dbName: 'dns_system',
            dbUser: 'root',
            dbPassword: '',
            adminUsername: 'admin',
            adminPassword: 'password',
            adminEmail: 'admin@example.com'
        })
    })
   .then(response => response.json())
   .then(data => {
        if (data.success) {
            // 显示完成信息
            document.getElementById('installStatus').innerHTML = `
                <div class="install-complete">
                    <div class="checkmark">
                        <svg width="80" height="80" viewBox="0 0 24 24">
                            <path fill="#4CAF50" d="M12,0C5.373,0,0,5.373,0,12c0,6.627,5.373,12,12,12s12-5.373,12-12C24,5.373,18.627,0,12,0z M12,20c-4.411,0-8-3.589-8-8s3.589-8,8-8s8,3.589,8,8S16.411,20,12,20z" />
                            <path fill="#4CAF50" d="M15.5,9.5L10.55,14.45L9.1,13l-4.7,4.7L2,12l7.8-7.8L12,6.2l3.5,3.5L15.5,9.5z" />
                        </svg>
                    </div>
                    <p>安装完成！</p>
                    <div style="display: flex; justify-content: center; gap: 20px; margin-top: 20px;">
                        <button id="enterBtn" class="install-btn enter-btn">进入首页</button>
                        <button id="adminBtn" class="install-btn enter-btn">管理后台</button>
                    </div>
                </div>
            `;

            // 添加按钮点击事件
            document.getElementById('enterBtn').addEventListener('click', function() {
                window.location.href = '../index.html';
            });

            document.getElementById('adminBtn').addEventListener('click', function() {
                alert('管理后台功能正在开发中，请等待...');
            });
        } else {
            alert('安装失败: ' + data.message);
            window.location.href = 'step2.php';
        }
    })
   .catch(error => {
        console.error('Error:', error);
        alert('安装失败: ' + error.message);
        window.location.href = 'step2.php';
    });
}