<?php
require_once 'install_progress.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['step'])) {
    $step = (int)$_GET['step'];
    if ($step >= 1 && $step <= 3) {
        try {
            InstallProgress::completeStep($step);
            error_log('安装进度更新成功，当前步骤: ' . $step);
            echo json_encode(['success' => true]);
            exit;
        } catch (Exception $e) {
            error_log('更新安装进度时出错: ' . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => '更新安装进度时出现错误: '. $e->getMessage()]);
            exit;
        }
    }
}

error_log('无效的步骤参数: ' . ($_GET['step'] ?? '未提供'));
http_response_code(400);
echo json_encode(['success' => false, 'error' => '无效的步骤参数']);