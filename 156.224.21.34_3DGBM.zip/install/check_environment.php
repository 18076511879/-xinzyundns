<?php
header('Content-Type: application/json');
header('Cache-Control: no-cache');

$response = ['success' => false];

try {
    if (!isset($_GET['check'])) {
        throw new InvalidArgumentException('缺少检测类型参数');
    }

    switch ($_GET['check']) {
        case 'version':
            $required = $_GET['required'] ?? '8.2';
            $current = phpversion();
            $response['success'] = version_compare($current, $required, '>=');
            $response['version'] = $current;
            break;

        case 'extensions':
            $extensions = explode(',', $_GET['extensions'] ?? '');
            $missing = [];
            foreach ($extensions as $ext) {
                if (!extension_loaded(trim($ext))) {
                    $missing[] = $ext;
                }
            }
            $response['success'] = empty($missing);
            $response['missing'] = $missing;
            break;

        default:
            throw new InvalidArgumentException('无效的检测类型');
    }
} catch (Exception $e) {
    $response['error'] = $e->getMessage();
}

echo json_encode($response);