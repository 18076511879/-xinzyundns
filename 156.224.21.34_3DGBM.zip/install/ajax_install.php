<?php
session_start();
header('Content-Type: application/json');

// 安全校验：仅允许POST请求且来自安装流程
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['install_step'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => '非法请求']);
    exit();
}

try {
    // 获取JSON数据（前端需发送application/json）
    $input = json_decode(file_get_contents('php://input'), true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('数据格式错误');
    }

    // 验证必填字段
    $required = ['adminUsername', 'adminEmail', 'dbHost', 'dbName', 'dbUser'];
    foreach ($required as $field) {
        if (empty($input[$field])) {
            throw new Exception("字段 $field 不能为空");
        }
    }

    // 加载数据库配置模板
    $configTemplate = file_get_contents('../application/config/database.php');
    $replacements = [
        '{{DB_HOST}}' => $input['dbHost'],
        '{{DB_PORT}}' => $input['dbPort'] ?? '3306',
        '{{DB_NAME}}' => $input['dbName'],
        '{{DB_USER}}' => $input['dbUser'],
        '{{DB_PASSWORD}}' => $input['dbPassword'] ?? '',
    ];
    $configContent = str_replace(array_keys($replacements), array_values($replacements), $configTemplate);
    file_put_contents('../application/config/database.php', $configContent);

    // 创建数据库连接
    $dsn = "mysql:host={$input['dbHost']};port={$input['dbPort']}";
    $pdo = new PDO($dsn, $input['dbUser'], $input['dbPassword'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);

    // 创建数据库
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$input['dbName']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
    $pdo->exec("USE `{$input['dbName']}`");

    // 执行SQL文件
    $sql = file_get_contents('../database.sql');
    $pdo->exec($sql);

    // 插入管理员（生成随机初始密码）
    $tempPassword = bin2hex(random_bytes(8)); // 示例: 2a1b3c4d
    $hashedPassword = password_hash($tempPassword, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, 'admin')");
    $stmt->execute([$input['adminUsername'], $hashedPassword, $input['adminEmail']]);

    // 创建安装锁文件
    if (!file_put_contents('../install.lock', 'Installed at ' . date('Y-m-d H:i:s'))) {
        throw new Exception('无法创建安装锁文件，请检查目录权限');
    }

    // 返回成功（包含临时密码）
    echo json_encode([
        'success' => true,
        'message' => '安装成功',
        'temp_password' => $tempPassword // 实际生产环境应通过邮件发送
    ]);

} catch (PDOException $e) {
    error_log('Database Error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => '数据库操作失败: ' . $e->getMessage()]);
} catch (Exception $e) {
    error_log('Install Error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}