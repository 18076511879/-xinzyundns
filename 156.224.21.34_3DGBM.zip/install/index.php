<?php
session_start();
header('Location: step1.php');
exit();