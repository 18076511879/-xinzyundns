<?php
header('Content-Type: application/json');

// 检查install.lock文件是否存在
$installed = file_exists('../install.lock');

echo json_encode(['installed' => $installed]);
?>