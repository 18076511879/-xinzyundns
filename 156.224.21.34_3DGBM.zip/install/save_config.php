<?php
session_start();
header('Content-Type: application/json');

try {
    $required = ['dbHost', 'dbPort', 'dbName', 'dbUser'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            throw new Exception("字段 $field 不能为空");
        }
    }

    // 生成数据库配置文件
    $config = [
        'host' => $_POST['dbHost'],
        'port' => $_POST['dbPort'],
        'name' => $_POST['dbName'],
        'user' => $_POST['dbUser'],
        'password' => $_POST['dbPassword'] ?? ''
    ];

    $configContent = "<?php\nreturn " . var_export($config, true) . ";\n";

    $configFile = '../application/config/database.php';
    if (!is_writable(dirname($configFile))) {
        throw new Exception('配置文件目录不可写，请检查目录权限');
    }

    if (!file_put_contents($configFile, $configContent)) {
        throw new Exception('无法写入配置文件，请检查目录权限');
    }

    // 保存管理员信息到Session
    $_SESSION['admin'] = [
        'username' => $_POST['adminUsername'],
        'password' => password_hash($_POST['adminPassword'], PASSWORD_DEFAULT),
        'email' => $_POST['adminEmail']
    ];

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    error_log('save_config.php 错误: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}