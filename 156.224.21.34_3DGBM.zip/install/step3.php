<?php
require_once 'install_progress.php';
InstallProgress::validateStep(3);

// 检查是否已安装
if (file_exists('../install.lock')) {
    header('Location: ../index.php');
    exit();
}

// 执行安装逻辑（保持原有数据库操作）
// ... [原有安装逻辑] ...

// 安装完成后写入锁定文件
if ($installationSuccess) {
    file_put_contents('../install.lock', 'Installed: ' . date('Y-m-d H:i:s'));
    unset($_SESSION['install']);
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>安装完成 - 步骤3/3</title>
    <link rel="stylesheet" href="css/installstep3.css">
</head>
<body>
    <div class="install-container">
        <div class="complete-card">
            <!-- 成功动画 -->
            <div class="success-animation">
                <svg class="checkmark" viewBox="0 0 52 52">
                    <circle class="checkmark-circle" cx="26" cy="26" r="25" fill="none"/>
                    <path class="checkmark-check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
                </svg>
            </div>

            <h1 class="complete-title">🎉 安装成功！</h1>
            <p class="complete-subtitle">系统已准备就绪，开始您的旅程吧</p>

            <div class="action-buttons">
                <a href="../index.php" class="action-btn home-btn">
                    <span class="btn-icon">🏠</span>
                    访问首页
                </a>
                <button class="action-btn admin-btn" onclick="showAdminNotice()">
                    <span class="btn-icon">⚙️</span>
                    管理后台
                </button>
            </div>

            <div class="tip-box">
                <div class="tip-icon">💡</div>
                <p>首次使用建议：<br>1. 修改默认管理员密码<br>2. 检查系统设置<br>3. 阅读使用文档</p>
            </div>
        </div>
    </div>

    <script>
    function showAdminNotice() {
        const alertBox = document.createElement('div');
        alertBox.className = 'admin-alert';
        alertBox.innerHTML = `
            <div class="alert-content">
                <h3>🚧 管理后台建设中</h3>
                <p>我们正在全力开发后台功能，敬请期待！</p>
                <button onclick="this.parentElement.parentElement.remove()" 
                        class="alert-confirm">
                    知道了
                </button>
            </div>
        `;
        document.body.appendChild(alertBox);
    }
    </script>
</body>
</html>