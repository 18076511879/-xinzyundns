<?php
require_once 'install_progress.php';
InstallProgress::validateStep(1);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>系统安装 - 步骤1/3</title>
    <link rel="stylesheet" href="css/installstep1.css">
</head>
<body>
    <div class="install-container">
        <div class="install-card">
            <div class="install-header">
                <h1>🔍 环境检测</h1>
                <div class="step-indicator">步骤 1/3</div>
            </div>
            
            <div class="detection-list">
                <div class="detection-item">
                    <div class="detection-label">
                        <span class="icon">📌</span>
                        PHP版本 (≥8.2)
                    </div>
                    <div id="phpVersionStatus" class="detection-status loading">
                        <div class="status-icon"></div>
                        <span class="status-text">检测中...</span>
                    </div>
                </div>
                
                <?php $extensions = ['mysqli', 'pdo_mysql', 'mbstring']; ?>
                <?php foreach ($extensions as $ext): ?>
                <div class="detection-item">
                    <div class="detection-label">
                        <span class="icon">🔧</span>
                        <?= strtoupper($ext) ?> 扩展
                    </div>
                    <div id="<?= $ext ?>Status" class="detection-status loading">
                        <div class="status-icon"></div>
                        <span class="status-text">检测中...</span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="action-buttons">
                <button id="nextStepBtn" class="btn next-btn" disabled>
                    <span class="btn-text">下一步</span>
                    <span class="btn-icon">➔</span>
                </button>
            </div>
        </div>
    </div>

    <script>
    const requirements = {
        phpVersion: '8.2',
        extensions: ['mysqli', 'pdo_mysql', 'mbstring']
    };

    async function checkRequirement(type, param) {
        try {
            const url = `check_environment.php?check=${type}&${new URLSearchParams(param)}`;
            const response = await fetch(url);
            return await response.json();
        } catch (error) {
            return { success: false };
        }
    }

    function updateStatus(elementId, success, message) {
        const element = document.getElementById(elementId);
        element.classList.remove('loading', 'success', 'error');
        element.classList.add(success ? 'success' : 'error');
        element.querySelector('.status-icon').textContent = success ? '✓' : '✗';
        element.querySelector('.status-text').textContent = message;
    }

    async function performChecks() {
        let allPassed = true;
        
        // PHP版本检测
        const versionRes = await checkRequirement('version', { required: requirements.phpVersion });
        updateStatus(
            'phpVersionStatus',
            versionRes.success,
            `${versionRes.success ? '符合要求' : '不符合'} (${versionRes.version})`
        );
        if (!versionRes.success) allPassed = false;

        // 扩展检测
        const extRes = await checkRequirement('extensions', { extensions: requirements.extensions });
        requirements.extensions.forEach(ext => {
            const success = !extRes.missing?.includes(ext);
            updateStatus(
                `${ext}Status`,
                success,
                success ? '已启用' : '未安装'
            );
            if (!success) allPassed = false;
        });

        // 更新按钮状态
        const nextBtn = document.getElementById('nextStepBtn');
        if (allPassed) {
            nextBtn.disabled = false;
            nextBtn.classList.add('enabled');
            nextBtn.onclick = async () => {
                await fetch('update_progress.php?step=1');
                window.location.href = 'step2.php';
            };
        }
    }

    window.addEventListener('DOMContentLoaded', performChecks);
    </script>
</body>
</html>