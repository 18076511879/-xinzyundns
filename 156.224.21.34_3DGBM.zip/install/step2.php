<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'install_progress.php';
InstallProgress::validateStep(2);

$configFile = '../application/config/database.php';
$config = [];
if (file_exists($configFile)) {
    $config = include $configFile;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>数据库配置 - 步骤2/3</title>
    <link rel="stylesheet" href="css/installstep2.css">
</head>
<body>
    <div class="install-container">
        <div class="install-card">
            <div class="install-header">
                <h1>⚙️ 数据库配置</h1>
                <div class="step-indicator">步骤 2/3</div>
            </div>
            
            <form id="dbConfigForm" class="config-form" method="POST">
                <!-- 数据库配置区块 -->
                <div class="config-section">
                    <h2 class="section-title">数据库设置</h2>
                    
                    <div class="form-group">
                        <label for="dbHost">
                            <span class="label-icon">🌐</span>
                            数据库主机
                        </label>
                        <input type="text" id="dbHost" name="dbHost" 
                               value="<?= htmlspecialchars($config['host'] ?? 'localhost') ?>" 
                               required>
                    </div>

                    <div class="form-group">
                        <label for="dbPort">
                            <span class="label-icon">🔌</span>
                            数据库端口
                        </label>
                        <input type="number" id="dbPort" name="dbPort" 
                               value="<?= htmlspecialchars($config['port'] ?? '3306') ?>"
                               min="1" max="65535" required>
                    </div>

                    <div class="form-group">
                        <label for="dbName">
                            <span class="label-icon">🗃️</span>
                            数据库名称
                        </label>
                        <input type="text" id="dbName" name="dbName" 
                               value="<?= htmlspecialchars($config['name'] ?? '') ?>"
                               required>
                    </div>

                    <div class="form-group">
                        <label for="dbUser">
                            <span class="label-icon">👤</span>
                            数据库用户
                        </label>
                        <input type="text" id="dbUser" name="dbUser" 
                               value="<?= htmlspecialchars($config['user'] ?? 'root') ?>"
                               required>
                    </div>

                    <div class="form-group">
                        <label for="dbPassword">
                            <span class="label-icon">🔑</span>
                            数据库密码
                        </label>
                        <input type="password" id="dbPassword" name="dbPassword"
                               placeholder="输入数据库密码"
                               value="<?= htmlspecialchars($config['password'] ?? '') ?>">
                    </div>
                </div>

                <!-- 管理员配置区块 -->
                <div class="config-section">
                    <h2 class="section-title">管理员账号</h2>
                    
                    <div class="form-group">
                        <label for="adminUsername">
                            <span class="label-icon">👑</span>
                            管理员名称
                        </label>
                        <input type="text" id="adminUsername" name="adminUsername"
                               value="admin" required>
                    </div>

                    <div class="form-group">
                        <label for="adminPassword">
                            <span class="label-icon">🛡️</span>
                            管理员密码
                        </label>
                        <input type="password" id="adminPassword" name="adminPassword"
                               placeholder="至少8位密码" 
                               minlength="8" required>
                    </div>

                    <div class="form-group">
                        <label for="adminEmail">
                            <span class="label-icon">📧</span>
                            管理员邮箱
                        </label>
                        <input type="email" id="adminEmail" name="adminEmail"
                               placeholder="admin@example.com" 
                               required>
                    </div>
                </div>

                <!-- 操作按钮 -->
                <div class="form-actions">
                    <button type="button" class="btn back-btn" onclick="history.back()">
                        ← 上一步
                    </button>
                    <button type="submit" class="btn submit-btn">
                        下一步 →
                    </button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>