// 检查是否已安装
if (!localStorage.getItem('install.lock')) {
    window.location.href = 'install/index.php';
}

// 显示/隐藏自定义服务器输入框
document.getElementById('destination').addEventListener('change', function() {
    const customServerGroup = document.getElementById('customServerGroup');
    if (this.value === 'custom') {
        customServerGroup.style.display = 'block';
    } else {
        customServerGroup.style.display = 'none';
    }
});

// 显示弹窗
function showModal(message) {
    const modal = document.getElementById('successModal');
    const modalMessage = document.getElementById('modalMessage');
    modalMessage.textContent = message;
    modal.style.display = 'flex';
    setTimeout(() => {
        modal.classList.add('show');
    }, 10);
}

// 关闭弹窗
function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('show');
    setTimeout(() => {
        modal.style.display = 'none';
    }, 300);
}

document.getElementById('closeModal').addEventListener('click', function() {
    hideModal('successModal');
});

// 表单提交处理
document.getElementById('domainForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const domain = document.getElementById('domain').value;
    const destination = document.getElementById('destination').value;
    const customServer = document.getElementById('customServer').value;
    
    // 模拟分发成功
    let message = `域名 ${domain} 已成功分发到 ${destination === 'custom' ? customServer : destination}`;
    showModal(message);
});

// 登录弹窗
document.getElementById('loginBtn').addEventListener('click', function() {
    const modal = document.getElementById('loginModal');
    modal.style.display = 'flex';
    setTimeout(() => {
        modal.classList.add('show');
    }, 10);
});

document.getElementById('closeLoginModal').addEventListener('click', function() {
    hideModal('loginModal');
});

document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('登录功能正在开发中，请等待...');
    hideModal('loginModal');
});

// 注册弹窗
document.getElementById('registerBtn').addEventListener('click', function() {
    const modal = document.getElementById('registerModal');
    modal.style.display = 'flex';
    setTimeout(() => {
        modal.classList.add('show');
    }, 10);
});

document.getElementById('closeRegisterModal').addEventListener('click', function() {
    hideModal('registerModal');
});

document.getElementById('registerForm').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('注册功能正在开发中，请等待...');
    hideModal('registerModal');
});

// 选择域名下拉框
document.getElementById('domainSelect').addEventListener('change', function() {
    document.getElementById('domain').value = this.value;
});